# RevenueOS POC Accelerator

A Streamlit MVP that turns a synthetic financial-services opportunity into an Ollama-generated, evidence-grounded POC plan and separate engineering handoff. Generation defaults to the local Ollama model; static planning is available only through an explicitly selected demo-fixture mode.

## Features

- Idempotent SQLite seeding of synthetic opportunity-won events.
- Keyword-overlap retrieval with match explanations and reviewer-feedback ranking adjustments.
- Real local model generation through Ollama's `POST /api/chat` endpoint.
- Structured JSON plan and handoff validation, including template ID and component checks.
- POC plans and Delivery handoffs are generated in separate bounded calls.
- `expected_workflow` must be a non-empty array; missing or invalid fields are never fabricated.
- Length-truncated calls get one higher-budget retry; a valid POC plan is retained if handoff generation fails.
- Generation timing, Ollama completion status, and validation errors are logged without customer briefs.
- The dashboard shows an in-progress status and disables repeat submission during generation.
- Persistent plan, generation/failure events, reviewer decisions, SLA breach triggers, and reuse metrics.
- US Solution Architect accept/edit/reject controls on one screen.
- Two-business-day pickup SLA in US Eastern time.

## Prerequisites and setup

- Python 3.10+ and the project dependencies.
- Ollama installed and running locally.
- The configured model already available in Ollama. This project does not download models.

```powershell
cd revenueos-poc-accelerator
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
ollama list
```

The current configured model is `qwen3:4b-instruct-2507-q4_K_M`. The HTTP client uses Python's standard library; no extra HTTP package is required. `.env.example` documents the variables but is not automatically loaded by Python or Streamlit. Set them in the shell before launching:

```powershell
$env:AGENT_MODE = "ollama"
$env:OLLAMA_BASE_URL = "http://localhost:11434"
$env:OLLAMA_MODEL = "qwen3:4b-instruct-2507-q4_K_M"
$env:OLLAMA_NUM_PREDICT = "2048"
$env:OLLAMA_RETRY_NUM_PREDICT = "3072"
streamlit run app.py
```

`AGENT_MODE` defaults to `ollama`; `OLLAMA_BASE_URL` and `OLLAMA_MODEL` have the values above as defaults. Each request uses `stream: false`, JSON response format, and disables Qwen thinking mode. The agent generates the POC plan and Delivery handoff in separate calls with concise customer-specific context. `OLLAMA_NUM_PREDICT` defaults to 2,048 tokens; an incomplete generation gets at most one retry using `OLLAMA_RETRY_NUM_PREDICT` (3,072 by default). Both values must be positive, and the retry limit must be higher. Missing or invalid fields may get one focused repair. Responses stopped for length are never parsed as complete JSON. If handoff generation fails after the plan validates, the plan section is retained in the workflow event log and the overall request still reports failure. The HTTP client separates a 10-second TCP connection timeout from a 720-second inference/read timeout; total generation is capped at 780 seconds. Performance metrics are logged without logging prompt content. `.gitignore` excludes local `.env` files; do not commit credentials.

## Verify the local Ollama integration

In another PowerShell terminal:

```powershell
Invoke-RestMethod http://localhost:11434/api/tags
ollama list
```

Confirm the configured model appears in the list. If the Ollama service is not running, start it with `ollama serve`; if the port is already occupied, the service may already be running. Use the exact installed model name in `OLLAMA_MODEL`.

In the existing dashboard, select an opportunity, load its brief, and click **Generate POC plan**. The workflow retrieves relevant templates, passes the brief and selected template contents to Ollama, validates the response, and saves the plan, separate Delivery handoff, template references, generation metadata, and workflow events to SQLite. The dashboard identifies successful Ollama output by model name and keeps it as a draft for human review.

If connection, model, JSON, or validation fails, the dashboard displays the error and the workflow log records the failure. Connection-establishment timeout, inference-response timeout, and Ollama HTTP errors are reported separately. There is no silent offline substitution. Correct the service/model/configuration and submit the brief again to retry. Length-truncated calls get at most one higher-budget retry; a validated POC plan remains in the workflow event log if the separate handoff call fails.

To explicitly run the non-AI fixture for a UI demonstration, use a separate shell:

```powershell
$env:AGENT_MODE = "demo"
streamlit run app.py
```

The app labels these plans **Explicit demo fixture — not AI-generated**. Set `AGENT_MODE` back to `ollama` to use the model.

## Opportunity, review, and SLA behavior

On startup, the app seeds synthetic opportunity records from `data/briefs.json`; repeated initialization does not duplicate IDs. Seeded account, brief, owner, region, and event timestamp are checked against the selected opportunity.

The pickup SLA starts from the original timezone-aware opportunity event timestamp, converted to US Eastern time (`America/New_York`). Weekends are excluded; public holidays are not yet accounted for. Green means before the one-business-day Amber threshold or picked up within the two-business-day SLA; Amber means at least one business day elapsed and the deadline has not passed; Red means the deadline passed without timely pickup. Plan creation time is never substituted for the source event time. Breach triggers are persisted once per plan.

The US Solution Architect can accept, edit, or reject a draft. Decisions are timestamped and linked to plan/opportunity IDs; edits, reasons, template IDs, and retained template IDs are persisted. Editing alone is not acceptance: accepted reuse metrics and positive ranking feedback require an explicit Accept action. Rejections provide negative ranking feedback. Only each plan's latest decision is used for metrics/ranking.

Template ranking adds `+0.05` for a template retained in a latest accepted plan and `-0.05` for each candidate in a latest rejected plan, summed across plans and clamped to `+/-0.20`. Edits alone do not add positive or negative feedback. This is a transparent score adjustment, not a trained model.

## Tests

Run all unit tests; Ollama HTTP calls are mocked:

```powershell
python -m unittest discover -s tests -v
python -m compileall -q app.py agent.py retrieval.py workflow.py database.py sla_monitor.py tests
```

To make a real local integration call, run the app with `AGENT_MODE=ollama` and generate a plan from the dashboard. The unit test suite does not require the service or make real model calls.

## Troubleshooting

- **Connection refused:** verify `ollama serve` is running and `OLLAMA_BASE_URL` points to the host/port reachable from the Python process.
- **Model not found:** run `ollama list` and set `OLLAMA_MODEL` to an installed tag. Do not rely on the app to download it.
- **Connection timeout:** TCP connection establishment is bounded at 10 seconds and reported as a connection failure.
- **Inference timeout:** once connected, response generation has a 720-second deadline, with a 780-second total plan deadline including any repair. It is reported as an inference timeout, not a connection failure. Check Ollama responsiveness and its logs.
- **Output token limit:** each stage gets one bounded retry at the higher `OLLAMA_RETRY_NUM_PREDICT` limit. A response with `done_reason=length` is never parsed or saved as complete; a validated POC plan is retained in workflow events if only the handoff stage fails.
- **Invalid JSON/sections/template reference or unsupported brief quote:** the agent performs at most one repair call. If validation still fails, the workflow reports the error and does not save a plan; review the brief and generated-output requirements before retrying.
- **The same validation error remains after updating code:** stop the Streamlit process with `Ctrl+C` in its terminal, confirm the terminal is in `revenueos-poc-accelerator`, and run `streamlit run app.py` again so the updated agent module is loaded.
- **Demo output shown:** check `AGENT_MODE`; the dashboard explicitly labels demo mode as non-AI.

## Project layout

```text
app.py                 Streamlit UI
database.py            SQLite persistence and workflow events
retrieval.py           Keyword-overlap template/example retrieval
agent.py               Ollama client, validation, and explicit demo fixture
workflow.py            Brief-to-plan orchestration
sla_monitor.py         Two-business-day SLA calculation
data/                  Synthetic opportunity events and solution templates
tests/                 Mocked agent and core workflow tests
docs/                  Build notes, cut list, and human-judgment boundary
```
