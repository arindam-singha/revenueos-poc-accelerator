# Cut list and scaling limits

## Deliberately deferred

- Authentication, multi-user identity, tenant isolation, and role-based authorization.
- CRM, document-store, ticketing, and production data integrations.
- Embedding/vector retrieval, reranking services, and managed model hosting.
- Background jobs, durable retries, request streaming, and model-provider failover.
- Model evaluation datasets, automated regression scoring, and production guardrail monitoring.
- US public holidays in SLA calculations; the current calendar excludes weekends only.
- Production deployment, backups, telemetry, and operational alert delivery.

## Likely first failures at 10x volume

- Keyword-overlap retrieval will produce weaker rankings as the template/example corpus grows; query relevance will degrade before SQLite capacity is the bottleneck.
- Synchronous Ollama calls in Streamlit will tie up request handling under concurrent users and can exceed the current bounded timeout.
- The single local Ollama model may queue requests or exhaust available memory/compute.
- The single SQLite file has no connection pool, workload separation, or operational backup policy; write contention and manual recovery are likely first persistence issues.
- Plan/evidence JSON and workflow-event tables are not paginated or retention-managed at scale.
- Dashboard-wide queries and per-refresh SLA synchronization have not been load-tested.

## Explicitly not claimed

The ranking adjustment is a bounded, explainable arithmetic signal based on latest reviewer outcomes. It is not model training or an autonomous learning system. Unit tests mock Ollama and do not establish model quality, latency, or safety.
